import { api } from "../utils/api";
import { apiEndpoints } from "../config/config";

const KATEGORI = apiEndpoints.kategori;

export const KategoriService = {
  get: (value = '') => {
    const path = value ? KATEGORI.get+value : KATEGORI.get;
    return api.get(path);
  },
  detail: (id) => api.get(`/api/artikel/${id}`),
  create: (data) => api.post(KATEGORI.create, data),
  update: (data) => api.patch(KATEGORI.update, data),
  delete: (id) => api.delete(KATEGORI.delete, id),
};
